package task2;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a day-long Excursion offered by a Cruise.
 * Demonstrates bidirectional relationships with Passenger objects.
 */
public class Excursion {
    private final Port destinationPort;
    private final String dayOfWeek;
    private final int passengerLimit;
    private final List<Passenger> passengersJoined;

    /**
     * Constructor for Excursion.
     * 
     * @param destinationPort Port where the excursion takes place
     * @param dayOfWeek Day of the week the excursion occurs
     * @param passengerLimit Maximum number of passengers allowed
     */
    public Excursion(Port destinationPort, String dayOfWeek, int passengerLimit) {
        this.destinationPort = destinationPort;
        this.dayOfWeek = dayOfWeek;
        this.passengerLimit = passengerLimit;
        this.passengersJoined = new ArrayList<>();
    }

    // --- Getter Methods ---
    public Port getDestinationPort() {
        return destinationPort;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public int getPassengerLimit() {
        return passengerLimit;
    }

    public List<Passenger> getPassengersJoined() {
        return passengersJoined;
    }

    // --- Status Methods ---
    /**
     * Calculates available spaces on the excursion.
     * 
     * @return Number of available spaces
     */
    public int getAvailableSpaces() {
        return passengerLimit - passengersJoined.size();
    }

    /**
     * Checks if the excursion is fully booked.
     * 
     * @return True if no spaces available, false otherwise
     */
    public boolean isFullyBooked() {
        return getAvailableSpaces() <= 0;
    }
    
    /**
     * Records a passenger booking, updating both the Excursion and the Passenger objects.
     * Demonstrates bidirectional relationship management.
     * 
     * @param passenger The passenger to add
     * @throws IllegalStateException if excursion is fully booked
     */
    public void addPassenger(Passenger passenger) {
        if (!isFullyBooked()) {
            this.passengersJoined.add(passenger);
            passenger.bookExcursion(this); // Update passenger's list (bidirectional)
        } else {
            throw new IllegalStateException("Excursion to " + destinationPort.getName() + " is fully booked.");
        }
    }
}