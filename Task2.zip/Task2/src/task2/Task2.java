package task2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

/**
 * Main application class for the Cruise Ship Administration System (Task 2).
 * Provides a console-based user interface and implements the required use cases.
 * 
 * This system demonstrates Object-Oriented Programming principles including:
 * - Inheritance: Cabin <- StandardCabin, Suite
 * - Polymorphism: Using abstract Cabin class methods
 * - Encapsulation: Private fields with public getters
 * - Composition: Cruise contains Ship, Ship contains Cabins, etc.
 */
public class Task2 {
    
    // --- Shared Resources and Constants ---
    private static final Scanner scanner = new Scanner(System.in);
    private static List<Cruise> allCruises; // Stores all available cruises

    // ANSI Colors for console output (only using GREEN for prompts as requested)
    private static final String RESET = "\u001B[0m";
    private static final String GREEN = "\u001B[32m"; // For all user prompts and important messages
    
    // Arrow prefix for every printed line to maintain consistent formatting
    private static final String ARROW = "-> ";

    /**
     * Main entry point of the Cruise Ship Administration System.
     * Initializes data and displays the main menu.
     * 
     * @param args Command line arguments (not used)
     */
    public static void main(String[] args) {
        displayWelcomeBanner();
        initializeData(); // Load initial test data
        displayMainMenu(); // Start interactive menu system
        scanner.close(); // Close scanner resource when done
    }
    
    // --- New Welcome Banner ---
    /**
     * Displays the welcome banner with system description.
     */
    private static void displayWelcomeBanner() {
        System.out.println(ARROW + "=".repeat(60));
        System.out.println(ARROW + " CRUISE SHIP ADMINISTRATION SYSTEM (TASK 2)");
        System.out.println(ARROW + "=".repeat(60));
        
        // Detailed description of system capabilities
        System.out.println(ARROW + "This system manages the core operations for multiple cruise ships,");
        System.out.println(ARROW + "focusing on passenger assignments and itinerary management.");
        System.out.println(ARROW + "It handles the following key entities and relationships:");
        System.out.println(ARROW + "  - Cruise Ships (Ship): Used for the cruise itinerary.");
        System.out.println(ARROW + "  - Passengers (Passenger): Assigned to a cruise and a specific cabin.");
        System.out.println(ARROW + "  - Cabins (Cabin, Suite, StandardCabin): Where passengers reside.");
        System.out.println(ARROW + "  - Excursions (Excursion): Activities offered at various Ports.");
        System.out.println(ARROW + "You can view information, book excursions, and change cabins.");
        
        System.out.println(ARROW + "=".repeat(60));
        System.out.println(ARROW + "System Initializing...");
    }
    
    // --- Data Initialization (Hardcoded) ---
    /**
     * Initializes the system with sample data for demonstration.
     * Creates ships, cabins, ports, excursions, cruises, and passengers.
     */
    private static void initializeData() {
        allCruises = new ArrayList<>();
        
        // --- Creating Ships and Cabins ---
        // Demonstrates polymorphism: StandardCabin and Suite are both Cabin objects
        Ship oasis = new Ship("Oasis of the Seas");
        oasis.addCabin(new Suite("S101", true));     // Suite with balcony
        oasis.addCabin(new Suite("S102", false));    // Suite without balcony
        oasis.addCabin(new StandardCabin("T201", true)); // Standard with sea view
        oasis.addCabin(new StandardCabin("T202", false)); // Standard without sea view
        oasis.addCabin(new StandardCabin("T203", false)); // Empty cabin for testing

        Ship mariner = new Ship("Mariner of the Seas");
        mariner.addCabin(new Suite("S301", true));
        mariner.addCabin(new StandardCabin("T401", true));
        mariner.addCabin(new StandardCabin("T402", true));

        Ship voyager = new Ship("Voyager of the Seas");
        voyager.addCabin(new Suite("S501", true));
        voyager.addCabin(new StandardCabin("T601", false));
        voyager.addCabin(new StandardCabin("T602", false));
        
        // --- Creating Ports ---
        Port barcelona = new Port("Barcelona, Spain");
        Port naples = new Port("Naples, Italy");
        Port athens = new Port("Athens, Greece");
        Port valletta = new Port("Valletta, Malta");
        
        // --- Creating Excursions ---
        // Each excursion has a destination port, day of week, and passenger limit
        Excursion oasisEx1 = new Excursion(barcelona, "Monday", 30);
        Excursion oasisEx2 = new Excursion(naples, "Wednesday", 50);
        Excursion oasisEx3 = new Excursion(athens, "Friday", 40);

        Excursion marinerEx1 = new Excursion(naples, "Tuesday", 50);
        Excursion marinerEx2 = new Excursion(valletta, "Thursday", 20);
        Excursion marinerEx3 = new Excursion(athens, "Sunday", 40);

        Excursion voyagerEx1 = new Excursion(barcelona, "Monday", 30);
        Excursion voyagerEx2 = new Excursion(valletta, "Wednesday", 20);
        Excursion voyagerEx3 = new Excursion(naples, "Friday", 50);

        // --- Creating Cruises and adding Excursions ---
        // Demonstrates composition: Cruise contains Ship and Excursions
        Cruise cruise1 = new Cruise(oasis); // Oasis Cruise
        cruise1.addExcursion(oasisEx1);
        cruise1.addExcursion(oasisEx2);
        cruise1.addExcursion(oasisEx3);

        Cruise cruise2 = new Cruise(mariner); // Mariner Cruise
        cruise2.addExcursion(marinerEx1);
        cruise2.addExcursion(marinerEx2);
        cruise2.addExcursion(marinerEx3);

        Cruise cruise3 = new Cruise(voyager); // Voyager Cruise
        cruise3.addExcursion(voyagerEx1);
        cruise3.addExcursion(voyagerEx2);
        cruise3.addExcursion(voyagerEx3);
        
        allCruises.addAll(Arrays.asList(cruise1, cruise2, cruise3));
        
        // --- Creating Passengers and assigning them to Cabins/Cruises ---
        
        // --- Oasis Passengers (Cruise 1) ---
        Passenger p1 = new Passenger("Alice Smith", cruise1);
        Passenger p2 = new Passenger("Bob Johnson", cruise1);
        Passenger p3 = new Passenger("Charlie Brown", cruise1);
        Passenger p4 = new Passenger("David Lee", cruise1);
        Passenger p5 = new Passenger("Emily White", cruise1);
        Passenger p6 = new Passenger("Frank Green", cruise1);
        
        Cabin oasisS101 = oasis.getCabins().get(0); // S101 Suite
        oasisS101.addPassenger(p1);
        oasisS101.addPassenger(p2); // Alice and Bob sharing S101

        Cabin oasisT201 = oasis.getCabins().get(2); // T201 Standard
        oasisT201.addPassenger(p3); // Charlie alone
        
        Cabin oasisT202 = oasis.getCabins().get(3); // T202 Standard
        oasisT202.addPassenger(p4);
        oasisT202.addPassenger(p5);
        oasisT202.addPassenger(p6); // David, Emily, Frank sharing T202
        
        // Add passengers to cruise
        cruise1.addPassenger(p1); cruise1.addPassenger(p2); cruise1.addPassenger(p3);
        cruise1.addPassenger(p4); cruise1.addPassenger(p5); cruise1.addPassenger(p6);
        
        // --- Mariner Passengers (Cruise 2) ---
        Passenger p7 = new Passenger("George Hall", cruise2);
        Passenger p8 = new Passenger("Hannah King", cruise2);
        
        Cabin marinerS301 = mariner.getCabins().get(0); // S301 Suite
        marinerS301.addPassenger(p7);
        marinerS301.addPassenger(p8);
        
        cruise2.addPassenger(p7); cruise2.addPassenger(p8);

        // --- Booking Excursions ---
        // Demonstrates bidirectional relationships between Passenger and Excursion
        oasisEx1.addPassenger(p1); // P1 (Alice): Books Excursion 1 (Barcelona)
        oasisEx2.addPassenger(p3); // P3 (Charlie): Books Excursion 2 (Naples)
        marinerEx1.addPassenger(p7); // P7 (George): Books Excursion 1 (Naples)
        marinerEx2.addPassenger(p8); // P8 (Hannah): Books Excursion 2 (Valletta)
        
        System.out.println(ARROW + "Successfully loaded initial data (3 Cruises, 8 Passengers, 5 Cabins occupied).");
        System.out.println(ARROW + "---------------------------------");
    }

    // --- Main Menu and Controller ---
    /**
     * Displays the main menu and handles user navigation.
     * Implements input validation for menu choices.
     */
    private static void displayMainMenu() {
        int choice;
        do {
            System.out.println("\n" + ARROW + "=".repeat(50));
            System.out.println(ARROW + " MAIN MENU");
            System.out.println(ARROW + "=".repeat(50));
            System.out.println(ARROW + "1. Display Cruise Information (Ship, Passengers, Excursions)");
            System.out.println(ARROW + "2. Display Excursion Information (Port, Day, Passenger List)");
            System.out.println(ARROW + "3. Display Passenger Information (Cabin, Cabin Mates, Bookings)");
            System.out.println(ARROW + "4. Book Excursion for a Passenger");
            System.out.println(ARROW + "5. Change Passenger Cabin (to vacant cabin)");
            System.out.println(ARROW + "0. Exit Application");
            System.out.println(ARROW + "=".repeat(50));
            System.out.print(GREEN + ARROW + "Enter your choice (0-5): " + RESET);

            // Enhanced input validation for menu choice
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                scanner.nextLine(); // consume newline
            } else {
                System.out.println(ARROW + "ERROR: Invalid input. Please enter a number between 0 and 5.");
                scanner.nextLine(); // consume invalid input
                choice = -1; // Set to invalid to trigger default case
            }

            try {
                switch (choice) {
                    case 1: 
                        displayCruiseInformation(); 
                        break;
                    case 2: 
                        displayExcursionInformation(); 
                        break;
                    case 3: 
                        displayPassengerInformation(); 
                        break;
                    case 4: 
                        bookExcursion(); 
                        break;
                    case 5: 
                        changePassengerCabin(); 
                        break;
                    case 0: 
                        System.out.println(ARROW + "Exiting application. Goodbye!"); 
                        break;
                    default: 
                        System.out.println(ARROW + "ERROR: Invalid option. Please choose a number between 0 and 5.");
                }
            } catch (Exception e) {
                System.out.println(ARROW + "ERROR: An unexpected error occurred: " + e.getMessage());
            }
        } while (choice != 0);
    }
    
    // --- Utility: Cruise Selection ---
    /**
     * Presents the user with a list of available cruises and returns the selected Cruise object.
     * Implements input validation for cruise selection.
     * 
     * @return The selected Cruise object, or null if selection is cancelled or invalid
     */
    private static Cruise selectCruise() {
        System.out.println("\n" + ARROW + "--- Select a Cruise Ship ---");
        for (int i = 0; i < allCruises.size(); i++) {
            System.out.printf(ARROW + "%d: %s\n", (i + 1), allCruises.get(i).getUsesShip().getName());
        }
        System.out.print(GREEN + ARROW + "Enter the index of the cruise (1-" + allCruises.size() + "): " + RESET);

        if (scanner.hasNextInt()) {
            int index = scanner.nextInt() - 1;
            scanner.nextLine();
            if (index >= 0 && index < allCruises.size()) {
                return allCruises.get(index);
            } else {
                System.out.println(ARROW + "ERROR: Invalid cruise selection. Please enter a number between 1 and " + allCruises.size() + ".");
                return null;
            }
        } else {
            scanner.nextLine(); // consume invalid input
            System.out.println(ARROW + "ERROR: Invalid input. Please enter a valid number.");
            return null;
        }
    }
    
    // --- Utility: Passenger Selection ---
    /**
     * Presents a list of passengers (sorted alphabetically) and returns the selected one.
     * Implements input validation for passenger selection.
     * 
     * @param cruise The cruise to select passengers from
     * @return The selected Passenger object, or null if selection is cancelled or invalid
     */
    private static Passenger selectPassenger(Cruise cruise) {
        List<Passenger> passengers = cruise.getIsOnPassengers().stream()
                .sorted(Comparator.comparing(Passenger::getName))
                .collect(Collectors.toList());

        if (passengers.isEmpty()) {
            System.out.println(ARROW + "ERROR: No passengers registered on this cruise.");
            return null;
        }

        System.out.println("\n" + ARROW + "--- Select a Passenger on " + cruise.getUsesShip().getName() + " ---");
        for (int i = 0; i < passengers.size(); i++) {
            System.out.printf(ARROW + "%d: %s\n", (i + 1), passengers.get(i).getName());
        }
        System.out.print(GREEN + ARROW + "Enter the index of the passenger (1-" + passengers.size() + "): " + RESET);

        if (scanner.hasNextInt()) {
            int index = scanner.nextInt() - 1;
            scanner.nextLine();
            if (index >= 0 && index < passengers.size()) {
                return passengers.get(index);
            } else {
                System.out.println(ARROW + "ERROR: Invalid passenger selection. Please enter a number between 1 and " + passengers.size() + ".");
                return null;
            }
        } else {
            scanner.nextLine(); // consume invalid input
            System.out.println(ARROW + "ERROR: Invalid input. Please enter a valid number.");
            return null;
        }
    }

    // --- USE CASE 1: Display Cruise Information ---
    /**
     * Displays comprehensive information about a selected cruise.
     * Shows ship details, passenger count, and available excursions.
     */
    private static void displayCruiseInformation() {
        Cruise cruise = selectCruise();
        if (cruise == null) return; // User cancelled or invalid selection

        Ship ship = cruise.getUsesShip();
        
        System.out.println("\n" + ARROW + "-------------------------------------------------");
        System.out.println(ARROW + " CRUISE INFORMATION for " + ship.getName());
        System.out.println(ARROW + "-------------------------------------------------");
        System.out.printf(ARROW + "Ship Name: %s\n", ship.getName());
        System.out.printf(ARROW + "Registered Passengers: %d\n", cruise.getNumberOfRegisteredPassengers());
        
        System.out.println(ARROW + "\nExcursions Offered:");
        System.out.println(ARROW + "-------------------");
        
        for (Excursion ex : cruise.getOffersExcursions()) {
            System.out.printf(ARROW + "- Port: %s\n", ex.getDestinationPort().getName());
            System.out.printf(ARROW + "  Day: %s\n", ex.getDayOfWeek());
            
            if (ex.isFullyBooked()) {
                System.out.println(ARROW + "  Status: " + GREEN + "Fully Booked" + RESET);
            } else {
                System.out.printf(ARROW + "  Spaces Available: %d (Limit: %d)\n", 
                                  ex.getAvailableSpaces(), ex.getPassengerLimit());
            }
        }
        System.out.println(ARROW + "-------------------------------------------------");
    }

    // --- USE CASE 2: Display Excursion Information ---
    /**
     * Displays detailed information about a selected excursion.
     * Shows excursion details and lists booked passengers alphabetically.
     */
    private static void displayExcursionInformation() {
        Cruise cruise = selectCruise();
        if (cruise == null) return;
        
        // List excursions for selection
        List<Excursion> excursions = cruise.getOffersExcursions();
        if (excursions.isEmpty()) {
            System.out.println(ARROW + "ERROR: No excursions available for this cruise.");
            return;
        }
        
        System.out.println("\n" + ARROW + "--- Select an Excursion on " + cruise.getUsesShip().getName() + " ---");
        for (int i = 0; i < excursions.size(); i++) {
            System.out.printf(ARROW + "%d: %s\n", (i + 1), excursions.get(i).getDestinationPort().getName());
        }
        System.out.print(GREEN + ARROW + "Enter the index of the excursion (1-" + excursions.size() + "): " + RESET);
        
        Excursion selectedExcursion = null;
        if (scanner.hasNextInt()) {
            int index = scanner.nextInt() - 1;
            scanner.nextLine();
            if (index >= 0 && index < excursions.size()) {
                selectedExcursion = excursions.get(index);
            } else {
                System.out.println(ARROW + "ERROR: Invalid excursion selection. Please enter a number between 1 and " + excursions.size() + ".");
                return;
            }
        } else {
            scanner.nextLine(); // consume invalid input
            System.out.println(ARROW + "ERROR: Invalid input. Please enter a valid number.");
            return;
        }
        
        // Display excursion details
        System.out.println("\n" + ARROW + "-------------------------------------------------");
        System.out.printf(ARROW + " EXCURSION DETAILS: %s\n", selectedExcursion.getDestinationPort().getName());
        System.out.println(ARROW + "-------------------------------------------------");
        System.out.printf(ARROW + "Day of Week: %s\n", selectedExcursion.getDayOfWeek());
        System.out.printf(ARROW + "Booking Limit: %d\n", selectedExcursion.getPassengerLimit());
        System.out.printf(ARROW + "Current Bookings: %d\n", selectedExcursion.getPassengersJoined().size());
        
        System.out.println(ARROW + "\nPassengers Booked (Alphabetical Order):");
        List<Passenger> bookedPassengers = selectedExcursion.getPassengersJoined().stream()
                .sorted(Comparator.comparing(Passenger::getName)) // Alphabetical order requirement
                .collect(Collectors.toList());

        if (bookedPassengers.isEmpty()) {
            System.out.println(ARROW + "  (No passengers currently booked)");
        } else {
            bookedPassengers.forEach(p -> System.out.println(ARROW + "  - " + p.getName()));
        }
        
        System.out.println(ARROW + "-------------------------------------------------");
    }

    // --- USE CASE 3: Display Passenger Information ---
    /**
     * Displays comprehensive information about a selected passenger.
     * Shows cabin details, cabin mates, and booked excursions.
     */
    private static void displayPassengerInformation() {
        Cruise cruise = selectCruise();
        if (cruise == null) return;
        
        Passenger passenger = selectPassenger(cruise);
        if (passenger == null) return;
        
        Cabin cabin = passenger.getResidesIn();
        
        System.out.println("\n" + ARROW + "-------------------------------------------------");
        System.out.printf(ARROW + " PASSENGER DETAILS: %s\n", passenger.getName());
        System.out.println(ARROW + "-------------------------------------------------");
        
        System.out.printf(ARROW + "Cruise Ship: %s\n", cruise.getUsesShip().getName());
        
        // Cabin Details - Demonstrates polymorphism through Cabin abstract class
        System.out.printf(ARROW + "Cabin Number: %s\n", cabin.getNumber());
        System.out.printf(ARROW + "Cabin Type: %s\n", cabin.getTypeDescription());
        
        // Cabin Mates
        System.out.println(ARROW + "\nCabin Sharing Details:");
        List<Passenger> mates = cabin.getCabinMates(passenger); // Already sorted alphabetically in the Cabin method
        
        if (mates.isEmpty()) {
            System.out.println(ARROW + "  Passenger is not sharing the cabin.");
        } else {
            System.out.println(ARROW + "  Sharing with (Alphabetical Order):");
            mates.forEach(p -> System.out.println(ARROW + "  - " + p.getName()));
        }
        
        // Excursions Booked
        System.out.println(ARROW + "\nExcursions Booked:");
        List<Excursion> booked = passenger.getExcursionsBooked();
        if (booked.isEmpty()) {
            System.out.println(ARROW + "  Passenger is not currently booked on any excursion.");
        } else {
            booked.forEach(ex -> System.out.printf(ARROW + "  - %s (%s)\n", 
                                 ex.getDestinationPort().getName(), ex.getDayOfWeek()));
        }
        
        System.out.println(ARROW + "-------------------------------------------------");
    }
    
    // --- USE CASE 4: Book Excursion ---
    /**
     * Allows booking an excursion for a selected passenger.
     * Validates availability and prevents double booking.
     */
    private static void bookExcursion() {
        Cruise cruise = selectCruise();
        if (cruise == null) return;
        
        Passenger passenger = selectPassenger(cruise);
        if (passenger == null) return;
        
        // Filter available excursions (not already booked and not fully booked)
        List<Excursion> availableExcursions = cruise.getOffersExcursions().stream()
                .filter(ex -> !passenger.getExcursionsBooked().contains(ex))
                .filter(ex -> !ex.isFullyBooked())
                .collect(Collectors.toList());

        if (availableExcursions.isEmpty()) {
            System.out.println(ARROW + "ERROR: No available excursions for " + passenger.getName() + " to book.");
            System.out.println(ARROW + "Either all excursions are fully booked or passenger has already booked all available excursions.");
            return;
        }

        System.out.println(ARROW + "\n--- Available Excursions for " + passenger.getName() + " ---");
        for (int i = 0; i < availableExcursions.size(); i++) {
            Excursion ex = availableExcursions.get(i);
            System.out.printf(ARROW + "%d: %s (Day: %s, Spaces: %d)\n", 
                              (i + 1), ex.getDestinationPort().getName(), ex.getDayOfWeek(), ex.getAvailableSpaces());
        }
        System.out.println(ARROW + "0: Cancel Booking (Return to Menu)");

        System.out.print(GREEN + ARROW + "Enter the index of the excursion to book (1-" + availableExcursions.size() + ", or 0 to cancel): " + RESET);
        
        if (scanner.hasNextInt()) {
            int index = scanner.nextInt();
            scanner.nextLine();
            
            if (index == 0) {
                System.out.println(ARROW + "Booking cancelled.");
                return;
            }
            
            int selectedIndex = index - 1;
            if (selectedIndex >= 0 && selectedIndex < availableExcursions.size()) {
                Excursion selectedEx = availableExcursions.get(selectedIndex);
                try {
                    // This updates both the Excursion and Passenger objects (bidirectional relationship)
                    selectedEx.addPassenger(passenger); 
                    System.out.println(GREEN + ARROW + "\n>>> SUCCESS: " + passenger.getName() + " successfully booked on the " 
                                       + selectedEx.getDestinationPort().getName() + " excursion." + RESET);
                } catch (IllegalStateException e) {
                    System.out.println(ARROW + "ERROR: Excursion is now fully booked. Please try again with a different excursion.");
                }
            } else {
                System.out.println(ARROW + "ERROR: Invalid selection index. Please enter a number between 1 and " + availableExcursions.size() + ".");
            }
        } else {
            scanner.nextLine(); // consume invalid input
            System.out.println(ARROW + "ERROR: Invalid input. Please enter a valid number.");
        }
    }
    
    // --- USE CASE 5: Change Passenger Cabin ---
    /**
     * Allows changing a passenger's cabin to a vacant one.
     * Moves the entire cabin group together and validates capacity.
     */
    private static void changePassengerCabin() {
        Cruise cruise = selectCruise();
        if (cruise == null) return;
        
        // 1. Identify vacant cabins (Current Occupancy is 0)
        List<Cabin> vacantCabins = cruise.getUsesShip().getCabins().stream()
                .filter(Cabin::isVacant)
                .collect(Collectors.toList());

        if (vacantCabins.isEmpty()) {
            System.out.println(ARROW + "ERROR: No vacant cabins available on " + cruise.getUsesShip().getName() + ".");
            return;
        }
        
        System.out.printf(ARROW + "\n%d vacant cabin(s) available.\n", vacantCabins.size());
        System.out.print(GREEN + ARROW + "Continue to change a passenger cabin? (Y/N): " + RESET);
        String proceed = scanner.nextLine().trim().toUpperCase();

        if (!"Y".equals(proceed)) {
            System.out.println(ARROW + "Cabin change cancelled.");
            return;
        }
        
        // 2. Select Passenger to move (and their cabin mates)
        Passenger leadPassenger = selectPassenger(cruise);
        if (leadPassenger == null) return;
        
        Cabin oldCabin = leadPassenger.getResidesIn();
        List<Passenger> passengersToMove = new ArrayList<>();
        passengersToMove.add(leadPassenger);
        passengersToMove.addAll(oldCabin.getCabinMates(leadPassenger));

        // The entire group must move together
        int requiredCapacity = passengersToMove.size();

        // 3. Select New Cabin - must have enough capacity
        System.out.println(ARROW + "\n--- Select New Cabin (Required Capacity: " + requiredCapacity + ") ---");
        List<Cabin> suitableVacantCabins = vacantCabins.stream()
                .filter(c -> c.getMaxCapacity() >= requiredCapacity)
                .collect(Collectors.toList());
        
        if (suitableVacantCabins.isEmpty()) {
            System.out.println(ARROW + "ERROR: No vacant cabins large enough to fit the group of " + requiredCapacity + " passengers.");
            System.out.println(ARROW + "Please select a different passenger or try again later.");
            return;
        }

        for (int i = 0; i < suitableVacantCabins.size(); i++) {
            Cabin c = suitableVacantCabins.get(i);
            System.out.printf(ARROW + "%d: %s (%s, Max: %d)\n", 
                              (i + 1), c.getNumber(), c.getTypeDescription(), c.getMaxCapacity());
        }
        System.out.print(GREEN + ARROW + "Enter the index of the new cabin (1-" + suitableVacantCabins.size() + "): " + RESET);
        
        Cabin newCabin = null;
        if (scanner.hasNextInt()) {
            int index = scanner.nextInt() - 1;
            scanner.nextLine();
            if (index >= 0 && index < suitableVacantCabins.size()) {
                newCabin = suitableVacantCabins.get(index);
            } else {
                System.out.println(ARROW + "ERROR: Invalid cabin selection. Please enter a number between 1 and " + suitableVacantCabins.size() + ".");
                return;
            }
        } else {
            scanner.nextLine(); // consume invalid input
            System.out.println(ARROW + "ERROR: Invalid input. Please enter a valid number.");
            return;
        }
        
        // 4. Perform the move
        System.out.println(ARROW + "\nProcessing cabin change...");
        
        // Move passengers one by one - demonstrates proper bidirectional relationship management
        for (Passenger p : passengersToMove) {
            oldCabin.removePassenger(p);
            newCabin.addPassenger(p); // addPassenger sets the new 'residesIn' reference on passenger
        }

        // Confirmation Message
        List<String> movedNames = passengersToMove.stream().map(Passenger::getName).collect(Collectors.toList());
        
        System.out.println(GREEN + ARROW + "\n>>> SUCCESS: Cabin change recorded!" + RESET);
        System.out.printf(ARROW + "Passengers Moved (%d): %s\n", requiredCapacity, String.join(", ", movedNames));
        System.out.printf(ARROW + "FROM Cabin: %s (%s)\n", oldCabin.getNumber(), oldCabin.getTypeDescription());
        System.out.printf(ARROW + "TO Cabin: %s (%s)\n", newCabin.getNumber(), newCabin.getTypeDescription());
        
        // Show new cabin status
        System.out.printf(ARROW + "New cabin occupancy: %d/%d\n", 
                          newCabin.getCurrentOccupancy(), newCabin.getMaxCapacity());
    }
}
