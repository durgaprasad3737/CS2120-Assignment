package task2;

/**
 * A Standard cabin. Accommodates up to 6 passengers. May have a sea view.
 * Concrete implementation of Cabin abstract class.
 * Demonstrates inheritance and polymorphism.
 */
public class StandardCabin extends Cabin {
    private final boolean hasSeaView;
    private static final int MAX_STANDARD_CAPACITY = 6;

    /**
     * Constructor for StandardCabin.
     * 
     * @param number Cabin number/identifier
     * @param hasSeaView Whether the cabin has a sea view
     */
    public StandardCabin(String number, boolean hasSeaView) {
        super(number, MAX_STANDARD_CAPACITY);
        this.hasSeaView = hasSeaView;
    }

    // --- Getter Methods ---
    public boolean hasSeaView() {
        return hasSeaView;
    }
    
    /**
     * Implementation of abstract method from Cabin class.
     * Demonstrates polymorphism: provides specific description for StandardCabin.
     * 
     * @return Description of cabin type with sea view status
     */
    @Override
    public String getTypeDescription() {
        return "Standard Cabin" + (hasSeaView ? " (w/ Sea View)" : " (No Sea View)");
    }
}