package task2;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a Passenger registered on a Cruise.
 * Demonstrates relationships with Cruise, Cabin, and Excursion objects.
 */
public class Passenger {
    private final String name;
    private final Cruise isOn; // The cruise the passenger is on
    private Cabin residesIn;    // The cabin the passenger is assigned to
    private final List<Excursion> excursionsBooked; // Excursions the passenger has joined

    /**
     * Constructor for Passenger.
     * 
     * @param name Passenger's name
     * @param isOn Cruise the passenger is registered on
     */
    public Passenger(String name, Cruise isOn) {
        this.name = name;
        this.isOn = isOn;
        this.excursionsBooked = new ArrayList<>();
    }

    // --- Getter Methods ---
    public String getName() {
        return name;
    }

    public Cruise getIsOn() {
        return isOn;
    }

    public Cabin getResidesIn() {
        return residesIn;
    }

    public List<Excursion> getExcursionsBooked() {
        return excursionsBooked;
    }

    // --- Setter for mutable relationships (only when moving cabin) ---
    /**
     * Sets the cabin where the passenger resides.
     * Used during cabin assignment or cabin change operations.
     * 
     * @param cabin The cabin to assign
     */
    public void setResidesIn(Cabin cabin) {
        this.residesIn = cabin;
    }
    
    // --- Booking Method ---
    /**
     * Records an excursion booking for this passenger.
     * Called by Excursion.addPassenger() to maintain bidirectional relationship.
     * 
     * @param excursion The excursion to book
     */
    public void bookExcursion(Excursion excursion) {
        this.excursionsBooked.add(excursion);
    }
}