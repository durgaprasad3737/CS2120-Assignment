package task1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Comparator;
import java.util.stream.Collectors;

/*
 * Main application class for NFL Super Bowl Database
 * This class demonstrates inheritance and polymorphism through abstract classes and interfaces
 */
public class Task1 {

    // Arrow prefix for user-facing output lines
    private static final String ARROW = "=> ";

    // ANSI colour for user input prompt (green) and reset
    private static final String GREEN = "\u001B[32m";
    private static final String RESET = "\u001B[0m";

    // Storage for Super Bowl records
    private static final List<Superbowl> superbowls = new ArrayList<>();

    // Single Scanner used throughout program
    private static final Scanner scanner = new Scanner(System.in);

    // ============================================================================
    // ABSTRACT CLASS: Defines common behavior for search operations
    // ============================================================================
    
    /**
     * Abstract base class for search operations
     * Demonstrates inheritance and polymorphism
     */
    abstract static class SearchOperation {
        protected String searchTerm;
        
        public SearchOperation(String searchTerm) {
            this.searchTerm = searchTerm;
        }
        
        /**
         * Abstract method that must be implemented by subclasses
         * @return List of Superbowl objects matching the search
         */
        public abstract List<Superbowl> performSearch();
        
        /**
         * Template method pattern - defines the search algorithm structure
         * @return true if results found, false otherwise
         */
        public final boolean execute() {
            System.out.println(ARROW + "Searching for: " + searchTerm);
            List<Superbowl> results = performSearch();
            
            if (results.isEmpty()) {
                displayNoResults();
                return false;
            } else {
                displayResults(results);
                return true;
            }
        }
        
        protected void displayNoResults() {
            System.out.println(ARROW + "No results found for: " + searchTerm);
        }
        
        protected abstract void displayResults(List<Superbowl> results);
    }
    
    // ============================================================================
    // CONCRETE SEARCH CLASSES: Implement specific search operations
    // ============================================================================
    
    /**
     * Concrete class for searching by year
     * Demonstrates inheritance from SearchOperation
     */
    static class YearSearch extends SearchOperation {
        private int year;
        
        public YearSearch(int year) {
            super(String.valueOf(year));
            this.year = year;
        }
        
        @Override
        public List<Superbowl> performSearch() {
            List<Superbowl> results = new ArrayList<>();
            for (Superbowl sb : superbowls) {
                if (sb.getYear() == year) {
                    results.add(sb);
                }
            }
            return results;
        }
        
        @Override
        protected void displayResults(List<Superbowl> results) {
            if (!results.isEmpty()) {
                Superbowl sb = results.get(0);
                System.out.println(ARROW + "Detailed result for year " + year + ":");
                System.out.println(sb.toString());
            }
        }
    }
    
    /**
     * Concrete class for searching by team
     * Demonstrates inheritance from SearchOperation
     */
    static class TeamSearch extends SearchOperation {
        
        public TeamSearch(String teamName) {
            super(teamName);
        }
        
        @Override
        public List<Superbowl> performSearch() {
            List<Superbowl> results = new ArrayList<>();
            String queryLower = searchTerm.toLowerCase();
            
            for (Superbowl sb : superbowls) {
                boolean winMatch = sb.getWinningTeam().toLowerCase().contains(queryLower);
                boolean loseMatch = sb.getLosingTeam().toLowerCase().contains(queryLower);
                
                if (winMatch || loseMatch) {
                    results.add(sb);
                }
            }
            
            results.sort(Comparator.comparing(Superbowl::getYear));
            return results;
        }
        
        @Override
        protected void displayResults(List<Superbowl> results) {
            // Display team search results in table format
            String separator = "-".repeat(90);
            System.out.println(separator);
            System.out.printf("| %-25s | %-15s | %-45s |%n", "Team", "No. appearances", "Details");
            System.out.println(separator);
            
            // Calculate wins and losses
            long winCount = results.stream()
                    .filter(sb -> sb.getWinningTeam().toLowerCase().contains(searchTerm.toLowerCase()))
                    .count();
            
            // Display results
            for (int i = 0; i < results.size(); i++) {
                Superbowl sb = results.get(i);
                String result = sb.getWinningTeam().toLowerCase().contains(searchTerm.toLowerCase()) ? 
                    "Winner" : "Runner-up";
                String details = String.format("%d (%s), %s", sb.getYear(), sb.getSuperbowlNumber(), result);
                
                if (i == 0) {
                    System.out.printf("| %-25s | %-15d | %-45s |%n", 
                        getDisplayTeamName(results), results.size(), details);
                } else {
                    System.out.printf("| %-25s | %-15s | %-45s |%n", "", "", details);
                }
            }
            
            System.out.println(separator);
            System.out.println(ARROW + "Wins: " + winCount + " | Losses: " + (results.size() - winCount));
        }
        
        private String getDisplayTeamName(List<Superbowl> results) {
            if (results.isEmpty()) return searchTerm;
            
            for (Superbowl sb : results) {
                if (sb.getWinningTeam().toLowerCase().contains(searchTerm.toLowerCase())) {
                    return sb.getWinningTeam();
                }
                if (sb.getLosingTeam().toLowerCase().contains(searchTerm.toLowerCase())) {
                    return sb.getLosingTeam();
                }
            }
            
            return searchTerm;
        }
    }
    
    // ============================================================================
    // INTERFACE: Defines contract for displayable objects
    // ============================================================================
    
    /**
     * Interface for objects that can be displayed
     * Demonstrates polymorphism through interface implementation
     */
    interface Displayable {
        void display();
    }
    
    /**
     * Concrete class implementing Displayable interface
     * Demonstrates polymorphism
     */
    static class StatisticsDisplay implements Displayable {
        @Override
        public void display() {
            displayStatistics();
        }
    }
    
    // ============================================================================
    // MAIN PROGRAM METHODS
    // ============================================================================
    
    /**
     * Main entry point of the application
     * @param args Command line arguments (not used)
     */
    public static void main(String[] args) {
        try (scanner) {
            displayWelcomeMessage();
            loadSuperbowlData();
            displayMenu();
        } catch (Exception e) {
            System.out.println(ARROW + "Unexpected error occurred: " + e.getMessage());
        }
    }

    /**
     * Displays welcome message with program overview
     */
    private static void displayWelcomeMessage() {
        // Printing the main title and banner
        System.out.println(ARROW + "=".repeat(70));
        System.out.println(ARROW + "NFL SUPER BOWL DATABASE");
        System.out.println(ARROW + "=".repeat(70));

        // Start of the detailed program overview content
        System.out.println(ARROW + " PROGRAM OVERVIEW");
        System.out.println(ARROW + "=".repeat(70));
        System.out.println(ARROW + "This system contains complete Super Bowl data from **1967 to 2024**.");
        System.out.println(ARROW + "You can explore, search, and analyze all Super Bowl games.");
        System.out.println();
        System.out.println(ARROW + "FEATURED TEAMS IN DATABASE (for search feature):");
        System.out.println(ARROW + "-".repeat(70));
        System.out.println(ARROW + "• New England Patriots • Pittsburgh Steelers • Dallas Cowboys");
        System.out.println(ARROW + "• San Francisco 49ers • Green Bay Packers • Denver Broncos");
        System.out.println(ARROW + "• Kansas City Chiefs • Philadelphia Eagles • Los Angeles Rams");
        System.out.println(ARROW + "• Miami Dolphins • Baltimore Ravens • New York Giants");
        System.out.println(ARROW + "• And all other NFL teams that have appeared in Super Bowls");
        System.out.println();
        System.out.println(ARROW + "DATA INCLUDES: Year, Date, Super Bowl Number, Winning/Losing");
        System.out.println(ARROW + "Teams with Scores, MVP, Stadium, City, and State");
        System.out.println(ARROW + "=".repeat(70));
        
        // Final prompt for user to continue, wrapped in GREEN for color highlight
        System.out.print(GREEN + ARROW + "Press Enter to continue..." + RESET);
        scanner.nextLine();
    }
    
    /**
     * Loads Super Bowl data from superbowls.txt file
     * Validates file existence and data integrity
     */
    private static void loadSuperbowlData() {
        String filePath = "src/task1/superbowls.txt";  // Changed this line only
        File file = new File(filePath);

        // Inform the user where we are trying to load data from
        System.out.println(ARROW + "Loading Super Bowl data from: " + file.getAbsolutePath());

        if (!file.exists()) {
            System.out.println(ARROW + "ERROR: superbowls.txt not found in project root.");
            System.out.println(ARROW + "Please add superbowls.txt and restart the program.");
            System.exit(1);
        }

        int recordsLoaded = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Skip empty lines and headers that contain the word "Year" (case-insensitive)
                if (line.trim().isEmpty() || line.toLowerCase().contains("year")) {
                    continue;
                }

                // Basic CSV split — assumes commas are not part of fields
                String[] data = line.split(",");

                if (data.length >= 11) {
                    try {
                        Superbowl sb = new Superbowl(
                            Integer.parseInt(data[0].trim()),   // year
                            data[1].trim(),                     // date
                            data[2].trim(),                     // superbowl number (roman)
                            data[3].trim(),                     // winning team
                            Integer.parseInt(data[4].trim()),   // winning points
                            data[5].trim(),                     // losing team
                            Integer.parseInt(data[6].trim()),   // losing points
                            data[7].trim(),                     // mvp
                            data[8].trim(),                     // stadium
                            data[9].trim(),                     // city
                            data[10].trim()                     // state
                        );
                        superbowls.add(sb);
                        recordsLoaded++;
                    } catch (NumberFormatException ex) {
                        // If an integer field is malformed, skip that line but inform the user
                        System.out.println(ARROW + "Skipping invalid line (number parse error): " + line);
                    }
                } else {
                    // Not enough columns in this CSV line
                    System.out.println(ARROW + "Skipping invalid line (missing fields): " + line);
                }
            }

            System.out.println(ARROW + "Successfully loaded " + recordsLoaded + " Super Bowl records.");
        } catch (IOException e) {
            System.out.println(ARROW + "Error reading file: " + e.getMessage());
            System.exit(1);
        }
    }
    
    /**
     * Displays the main interactive menu
     * Handles user input with validation
     */
    private static void displayMenu() {
        int choice;
        do {
            System.out.println();
            System.out.println(ARROW + "=".repeat(60));
            System.out.println(ARROW + "NFL SUPER BOWL DATABASE MENU");
            System.out.println(ARROW + "=".repeat(60));
            System.out.println(ARROW + "1. View All Super Bowls (Table)");
            System.out.println(ARROW + "2. Search by Year (Detailed)");
            System.out.println(ARROW + "3. Search by Team/State (Detailed)");
            System.out.println(ARROW + "4. View Statistics");
            System.out.println(ARROW + "5. Program Information");
            System.out.println(ARROW + "0. Exit");
            System.out.println(ARROW + "=".repeat(60));

            // Prompt for user choice in green with input validation
            System.out.print(GREEN + ARROW + "Enter your choice (0-5): " + RESET);
            
            // Enhanced input validation with error handling
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                scanner.nextLine(); // consume leftover newline
                
                // Validate menu choice range
                if (choice < 0 || choice > 5) {
                    System.out.println(ARROW + "ERROR: Invalid choice. Please enter a number between 0 and 5.");
                    choice = -1; // Reset choice to trigger default case
                }
            } else {
                System.out.println(ARROW + "ERROR: Invalid input. Expected a number between 0 and 5.");
                scanner.nextLine(); // discard bad token
                choice = -1;
            }

            switch (choice) {
                case 1:
                    displayAllSuperbowlsTable();
                    break;
                case 2:
                    searchByYear();
                    break;
                case 3:
                    searchByTeamStateMenu();
                    break;
                case 4:
                    // Using polymorphism through the Displayable interface
                    Displayable statsDisplay = new StatisticsDisplay();
                    statsDisplay.display();
                    break;
                case 5:
                    displayProgramInfo();
                    break;
                case 0:
                    System.out.println(ARROW + "Thank you. Exiting program.");
                    break;
                default:
                    if (choice != -1) {
                        System.out.println(ARROW + "ERROR: Please enter a valid option (0-5).");
                    }
            }
        } while (choice != 0);
    }

    /**
     * Displays all Super Bowls in a formatted table
     */
    private static void displayAllSuperbowlsTable() {
        if (superbowls.isEmpty()) {
            System.out.println(ARROW + "No Super Bowl data available.");
            return;
        }
        
        System.out.println();
        System.out.println(ARROW + "=".repeat(120));
        System.out.println(ARROW + "ALL SUPER BOWLS (" + superbowls.size() + " GAMES)");
        System.out.println(ARROW + "=".repeat(120));

        // Table header printed without ARROW for easier scanning
        System.out.printf("%-6s %-8s %-28s %-8s %-28s %-8s %-20s%n",
            "YEAR", "SB", "WINNING TEAM", "W-SCORE", "LOSING TEAM", "L-SCORE", "LOCATION");
        System.out.println("-".repeat(120));

        // Table rows (no ARROW)
        for (Superbowl sb : superbowls) {
            System.out.printf("%-6d %-8s %-28s %-8d %-28s %-8d %-20s%n",
                sb.getYear(),
                sb.getSuperbowlNumber(),
                shortenName(sb.getWinningTeam()),
                sb.getWinningPoints(),
                shortenName(sb.getLosingTeam()),
                sb.getLosingPoints(),
                shortenLocation(sb.getCity() + ", " + sb.getState()));
        }

        System.out.println("=".repeat(120));
        System.out.println(ARROW + "Total records: " + superbowls.size());

        // Wait for the user to press Enter — highlight the prompt in green
        System.out.print(GREEN + ARROW + "Press Enter to return to the main menu..." + RESET);
        scanner.nextLine();
    }

    /**
     * Searches for Super Bowl by year with enhanced input validation
     * Demonstrates polymorphism through SearchOperation abstract class
     */
    private static void searchByYear() {
        System.out.print(GREEN + ARROW + "Enter Super Bowl year (1967-2024): " + RESET);

        int year;
        if (scanner.hasNextInt()) {
            year = scanner.nextInt();
            scanner.nextLine();
            
            // Enhanced validation: check year range
            if (year < 1967 || year > 2024) {
                System.out.println(ARROW + "ERROR: Year must be between 1967 and 2024.");
                System.out.print(GREEN + ARROW + "Press Enter to return..." + RESET);
                scanner.nextLine();
                return;
            }
        } else {
            System.out.println(ARROW + "ERROR: Invalid year input. Please enter a valid year (e.g., 2020).");
            scanner.nextLine();
            System.out.print(GREEN + ARROW + "Press Enter to return..." + RESET);
            scanner.nextLine();
            return;
        }

        // Using polymorphism through SearchOperation abstract class
        SearchOperation search = new YearSearch(year);
        boolean found = search.execute();

        if (!found) {
            System.out.println(ARROW + "ERROR: No Super Bowl record found for year " + year + ".");
            System.out.println(ARROW + "Note: Super Bowls are played in February of the following year.");
        }

        System.out.print(GREEN + ARROW + "Press Enter to return..." + RESET);
        scanner.nextLine();
    }
    
    /**
     * Displays submenu for searching by team or state
     * Handles user input with validation
     */
    private static void searchByTeamStateMenu() {
        int choice;
        do {
            System.out.println();
            System.out.println("-".repeat(30));
            System.out.println("Search superbowls by:");
            System.out.println("-".repeat(30));
            System.out.println("Team ...................1");
            System.out.println("State...................2");
            System.out.println("Main menu...............0");
            System.out.println("-".repeat(30));
            System.out.print(GREEN + "Enter choice:>" + RESET); 

            // Input validation for submenu choice
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                scanner.nextLine(); // consume leftover newline
                
                // Validate submenu choice range
                if (choice < 0 || choice > 2) {
                    System.out.println(ARROW + "ERROR: Invalid choice. Please enter 0, 1, or 2.");
                    choice = -1;
                }
            } else {
                System.out.println(ARROW + "ERROR: Invalid input. Expected a number (0-2).");
                scanner.nextLine(); // discard bad token
                choice = -1;
            }

            switch (choice) {
                case 1:
                    searchByTeamDetail();
                    break;
                case 2:
                    searchByStateDetail();
                    break;
                case 0:
                    System.out.println(ARROW + "Returning to main menu.");
                    break;
                default:
                    if (choice != -1) {
                        System.out.println(ARROW + "ERROR: Please enter a valid option (0-2).");
                    }
            }
        } while (choice != 0);
    }

    /**
     * Searches for Super Bowls by team name with input validation
     * Demonstrates polymorphism through SearchOperation abstract class
     */
    private static void searchByTeamDetail() {
        System.out.print(GREEN + ARROW + "Enter search term for NFL team (e.g., Dallas): " + RESET);
        String teamName = scanner.nextLine().trim();
        
        // Input validation for team name
        if (teamName.isEmpty()) {
            System.out.println(ARROW + "ERROR: Please provide a team name.");
            return;
        }
        
        if (teamName.length() < 2) {
            System.out.println(ARROW + "ERROR: Search term must be at least 2 characters.");
            return;
        }

        // Using polymorphism through SearchOperation abstract class
        SearchOperation search = new TeamSearch(teamName);
        search.execute();

        System.out.print(GREEN + ARROW + "Press Enter to return to the search menu..." + RESET);
        scanner.nextLine();
    }
    
    /**
     * Searches for Super Bowls by state with input validation
     */
    private static void searchByStateDetail() {
        System.out.print(GREEN + ARROW + "Enter search term for U.S. state (e.g., Florida): " + RESET);
        String stateName = scanner.nextLine().trim();
        
        // Input validation for state name
        if (stateName.isEmpty()) {
            System.out.println(ARROW + "ERROR: Please provide a state name.");
            return;
        }
        
        if (stateName.length() < 2) {
            System.out.println(ARROW + "ERROR: Search term must be at least 2 characters.");
            return;
        }

        // Case-insensitive query
        final String queryLower = stateName.toLowerCase();
        
        // List to hold Superbowl records hosted in the matching state, sorted by year
        List<Superbowl> hostedGames = superbowls.stream()
                                    .filter(sb -> sb.getState().toLowerCase().contains(queryLower))
                                    .sorted(Comparator.comparing(Superbowl::getYear)) 
                                    .collect(Collectors.toList());

        if (hostedGames.isEmpty()) {
            System.out.println(ARROW + "ERROR: No Super Bowl games found hosted in a state matching: " + stateName);
            System.out.println(ARROW + "Tip: Try entering the full state name (e.g., 'California' instead of 'CA').");
        } else {
            String actualStateName = hostedGames.get(0).getState();
            String separator = "-".repeat(90);

            System.out.println(separator);
            System.out.printf("| %-20s | %-15s | %-50s |%n", "State", "Superbowl", "City & Stadium");
            System.out.println(separator);
            
            for (int i = 0; i < hostedGames.size(); i++) {
                Superbowl sb = hostedGames.get(i);
                String sbDetails = String.format("%s (%d)", sb.getSuperbowlNumber(), sb.getYear());
                String location = String.format("%s, %s", sb.getCity(), sb.getStadium());
                
                if (i == 0) {
                    System.out.printf("| %-20s | %-15s | %-50s |%n", actualStateName, sbDetails, location);
                } else {
                    System.out.printf("| %-20s | %-15s | %-50s |%n", "", sbDetails, location);
                }
            }
            
            System.out.println(separator);
            System.out.println(ARROW + "Total Super Bowls hosted in " + actualStateName + ": " + hostedGames.size());
        }

        System.out.print(GREEN + ARROW + "Press Enter to return to the search menu..." + RESET);
        scanner.nextLine();
    }
    
    /**
     * Displays Super Bowl statistics
     */
    private static void displayStatistics() {
        if (superbowls.isEmpty()) {
            System.out.println(ARROW + "ERROR: No data available to compute statistics.");
            System.out.print(GREEN + ARROW + "Press Enter to return..." + RESET);
            scanner.nextLine();
            return;
        }

        System.out.println();
        System.out.println(ARROW + "=".repeat(80));
        System.out.println(ARROW + "SUPER BOWL STATISTICS");
        System.out.println(ARROW + "=".repeat(80));

        int totalGames = superbowls.size();
        int highestScore = 0;
        int closestMargin = Integer.MAX_VALUE;
        double totalPoints = 0;

        Superbowl highestScoring = null;
        Superbowl closestGame = null;

        for (Superbowl sb : superbowls) {
            int totalPointsGame = sb.getWinningPoints() + sb.getLosingPoints();
            int margin = Math.abs(sb.getWinningPoints() - sb.getLosingPoints());
            totalPoints += totalPointsGame;

            if (totalPointsGame > highestScore) {
                highestScore = totalPointsGame;
                highestScoring = sb;
            }

            if (margin < closestMargin) {
                closestMargin = margin;
                closestGame = sb;
            }
        }

        double avgPoints = totalPoints / totalGames;

        System.out.println(ARROW + "Total Games: " + totalGames);
        System.out.printf(ARROW + "Average Points per Game: %.1f%n", avgPoints);
        if (highestScoring != null) {
            System.out.printf(ARROW + "Highest Scoring Game: %d - %s vs %s (%d combined points)%n",
                highestScoring.getYear(),
                shortenName(highestScoring.getWinningTeam()),
                shortenName(highestScoring.getLosingTeam()),
                highestScore);
        }
        if (closestGame != null) {
            System.out.printf(ARROW + "Closest Game: %d - %s vs %s (%d point margin)%n",
                closestGame.getYear(),
                shortenName(closestGame.getWinningTeam()),
                shortenName(closestGame.getLosingTeam()),
                closestMargin);
        }

        // Count championships per team
        System.out.println();
        System.out.println(ARROW + "Top Championship Records:");
        System.out.println(ARROW + "-".repeat(40));

        java.util.Map<String, Integer> wins = new java.util.HashMap<>();
        for (Superbowl sb : superbowls) {
            wins.put(sb.getWinningTeam(), wins.getOrDefault(sb.getWinningTeam(), 0) + 1);
        }

        System.out.printf("%-30s %-10s%n", "TEAM", "CHAMPIONSHIPS");
        System.out.println("-".repeat(40));
        wins.entrySet().stream()
            .sorted((a, b) -> b.getValue().compareTo(a.getValue()))
            .limit(5)
            .forEach(entry -> {
                System.out.printf("%-30s %-10d%n", shortenName(entry.getKey()), entry.getValue());
            });

        System.out.println(ARROW + "=".repeat(80));
        System.out.print(GREEN + ARROW + "Press Enter to return..." + RESET);
        scanner.nextLine();
    }

    /**
     * Displays program information
     */
    private static void displayProgramInfo() {
        System.out.println();
        System.out.println(ARROW + "=".repeat(70));
        System.out.println(ARROW + "PROGRAM INFORMATION");
        System.out.println(ARROW + "=".repeat(70));
        System.out.println(ARROW + "This program holds Super Bowl records including:");
        System.out.println(ARROW + "- Year, Date, Super Bowl number");
        System.out.println(ARROW + "- Winning/Losing teams and scores");
        System.out.println(ARROW + "- MVP, Stadium, City and State");
        System.out.println();
        System.out.println(ARROW + "You can:");
        System.out.println(ARROW + "1) View all games in a table");
        System.out.println(ARROW + "2) Search by a specific year for detailed info");
        System.out.println(ARROW + "3) Search by team name (partial matches allowed)");
        System.out.println(ARROW + "4) View basic statistics and top champions");
        System.out.println(ARROW + "0) Exit the program");
        System.out.println(ARROW + "=".repeat(70));

        System.out.print(GREEN + ARROW + "Press Enter to return..." + RESET);
        scanner.nextLine();
    }
    
    // ============================================================================
    // UTILITY METHODS
    // ============================================================================
    
    /**
     * Shortens common long team names to make tables neater
     * @param name Original team name
     * @return Shortened team name for display
     */
    private static String shortenName(String name) {
        if (name == null) return "";
        if (name.length() <= 28) return name;
        return name.replace("Green Bay", "GB")
                   .replace("Kansas City", "KC")
                   .replace("New England", "NE")
                   .replace("San Francisco", "SF")
                   .replace("Los Angeles", "LA")
                   .replace("St. Louis", "StL");
    }

    /**
     * Shortens common location long names for table width
     * @param location Original location string
     * @return Shortened location for display
     */
    private static String shortenLocation(String location) {
        if (location == null) return "";
        if (location.length() <= 20) return location;
        return location.replace("Miami Gardens", "Miami, FL")
                       .replace("East Rutherford, New Jersey", "E.Rutherford, NJ")
                       .replace("New Orleans, Louisiana", "NOLA, LA");
    }
}
