package task2;

/**
 * A Suite cabin. Accommodates up to 4 passengers. May have a balcony.
 * Concrete implementation of Cabin abstract class.
 * Demonstrates inheritance and polymorphism.
 */
public class Suite extends Cabin {
    private final boolean hasBalcony;
    private static final int MAX_SUITE_CAPACITY = 4;

    /**
     * Constructor for Suite.
     * 
     * @param number Cabin number/identifier
     * @param hasBalcony Whether the suite has a balcony
     */
    public Suite(String number, boolean hasBalcony) {
        super(number, MAX_SUITE_CAPACITY);
        this.hasBalcony = hasBalcony;
    }

    // --- Getter Methods ---
    public boolean hasBalcony() {
        return hasBalcony;
    }

    /**
     * Implementation of abstract method from Cabin class.
     * Demonstrates polymorphism: provides specific description for Suite.
     * 
     * @return Description of cabin type with balcony status
     */
    @Override
    public String getTypeDescription() {
        return "Suite" + (hasBalcony ? " (w/ Balcony)" : " (No Balcony)");
    }
}