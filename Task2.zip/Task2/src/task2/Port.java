package task2;

/**
 * Represents a Port of call for an Excursion.
 * Simple value object with name property.
 */
public class Port {
    private final String name;

    /**
     * Constructor for Port.
     * 
     * @param name Name of the port
     */
    public Port(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    /**
     * String representation of Port (just the name).
     * 
     * @return Port name
     */
    @Override
    public String toString() {
        return name;
    }
}