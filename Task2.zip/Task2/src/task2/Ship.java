package task2;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a Ship used for a cruise. Each ship has a unique name and a collection of Cabins.
 * Demonstrates composition: Ship contains Cabins.
 */
public class Ship {
    private final String name;
    private final List<Cabin> cabins;

    /**
     * Constructor for Ship.
     * 
     * @param name Name of the ship
     */
    public Ship(String name) {
        this.name = name;
        this.cabins = new ArrayList<>();
    }

    // --- Getter Methods ---
    public String getName() {
        return name;
    }

    public List<Cabin> getCabins() {
        return cabins;
    }

    /**
     * Adds a cabin to the ship.
     * Demonstrates polymorphism: accepts any Cabin subclass (Suite or StandardCabin).
     * 
     * @param cabin The cabin to add
     */
    public void addCabin(Cabin cabin) {
        this.cabins.add(cabin);
    }
}

