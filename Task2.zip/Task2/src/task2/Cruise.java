package task2;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a specific one-week cruise, using a single Ship.
 * Demonstrates composition: Cruise contains Ship, Excursions, and Passengers.
 */
public class Cruise {
    private final Ship usesShip;
    private final List<Excursion> offersExcursions;
    private final List<Passenger> isOnPassengers;

    /**
     * Constructor for Cruise.
     * 
     * @param usesShip The ship used for this cruise
     */
    public Cruise(Ship usesShip) {
        this.usesShip = usesShip;
        this.offersExcursions = new ArrayList<>();
        this.isOnPassengers = new ArrayList<>();
    }

    // --- Getter Methods ---
    public Ship getUsesShip() {
        return usesShip;
    }

    public List<Excursion> getOffersExcursions() {
        return offersExcursions;
    }

    public List<Passenger> getIsOnPassengers() {
        return isOnPassengers;
    }

    // --- Management Methods ---
    /**
     * Adds an excursion to the cruise's offerings.
     * 
     * @param excursion The excursion to add
     */
    public void addExcursion(Excursion excursion) {
        this.offersExcursions.add(excursion);
    }

    /**
     * Adds a passenger to the cruise.
     * 
     * @param passenger The passenger to add
     */
    public void addPassenger(Passenger passenger) {
        this.isOnPassengers.add(passenger);
    }

    /**
     * Gets the number of registered passengers on the cruise.
     * 
     * @return Total number of passengers
     */
    public int getNumberOfRegisteredPassengers() {
        return isOnPassengers.size();
    }
}