package task1;

import java.lang.StringBuilder;

/**
 * Represents a single Super Bowl game entry.
 * This is an immutable data class that stores all information about a Super Bowl game.
 * All fields are final to ensure thread safety and data consistency.
 */
public class Superbowl {

    // --- Attributes (Instance Fields) ---
    // All fields are final to create an immutable object
    private final int year;                // Year the Super Bowl was played (e.g., 2020)
    private final String date;             // Exact date of the game (e.g., "February 7, 2021")
    private final String superbowlNumber;  // Roman numeral representation (e.g., "LV")
    private final String winningTeam;      // Name of the winning team
    private final int winningPoints;       // Points scored by the winning team
    private final String losingTeam;       // Name of the losing team
    private final int losingPoints;        // Points scored by the losing team
    private final String mvp;              // Most Valuable Player name
    private final String stadium;          // Name of the stadium where game was played
    private final String city;             // City where stadium is located
    private final String state;            // State where stadium is located

    // --- Constructor ---
    /**
     * Creates a new Superbowl object with all required game data.
     * 
     * @param year The year the Super Bowl was played
     * @param date The date of the game
     * @param superbowlNumber Roman numeral representation of the Super Bowl
     * @param winningTeam Name of the winning team
     * @param winningPoints Points scored by winning team
     * @param losingTeam Name of the losing team
     * @param losingPoints Points scored by losing team
     * @param mvp Most Valuable Player
     * @param stadium Stadium name
     * @param city City where stadium is located
     * @param state State where stadium is located
     */
    public Superbowl(int year, String date, String superbowlNumber, String winningTeam, int winningPoints,
                     String losingTeam, int losingPoints, String mvp, String stadium, String city, String state) {
        this.year = year;
        this.date = date;
        this.superbowlNumber = superbowlNumber;
        this.winningTeam = winningTeam;
        this.winningPoints = winningPoints;
        this.losingTeam = losingTeam;
        this.losingPoints = losingPoints;
        this.mvp = mvp;
        this.stadium = stadium;
        this.city = city;
        this.state = state;
    }

    // --- Getter Methods ---
    /**
     * Gets the year of the Super Bowl game
     * @return Year as integer
     */
    public int getYear() {
        return year;
    }

    /**
     * Gets the Super Bowl number in Roman numerals
     * @return Super Bowl number as Roman numeral string
     */
    public String getSuperbowlNumber() {
        return superbowlNumber;
    }

    /**
     * Gets the winning team name
     * @return Winning team name
     */
    public String getWinningTeam() {
        return winningTeam;
    }

    /**
     * Gets the winning team's points
     * @return Winning points as integer
     */
    public int getWinningPoints() {
        return winningPoints;
    }
    
    /**
     * Gets the losing team name
     * @return Losing team name
     */
    public String getLosingTeam() {
        return losingTeam;
    }
    
    /**
     * Gets the losing team's points
     * @return Losing points as integer
     */
    public int getLosingPoints() {
        return losingPoints;
    }

    /**
     * Gets the Most Valuable Player name
     * @return MVP name
     */
    public String getMvp() {
        return mvp;
    }
    
    /**
     * Gets the city where the game was played
     * @return City name
     */
    public String getCity() {
        return city;
    }
    
    /**
     * Gets the state where the game was played
     * @return State name
     */
    public String getState() {
        return state;
    }
    
    /**
     * Gets the stadium name where the game was played
     * @return Stadium name
     */
    public String getStadium() {
        return stadium;
    }

    // --- Detailed toString() Method for Option 2 (Search by Year) ---
    /**
     * Returns a formatted string representation of the Super Bowl details
     * This is used for detailed display when searching by year
     * 
     * @return Formatted string with all Super Bowl details
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        // Using the ">> " prefix as per your initial requirement
        sb.append("\n>> =======================================================");
        sb.append("\n>> Superbowl ").append(superbowlNumber).append(" (").append(year).append(") - ").append(date);
        sb.append("\n>> -------------------------------------------------------");
        sb.append("\n>> WINNER: ").append(winningTeam).append(String.format(" (%d points)", winningPoints));
        sb.append("\n>> LOSER:  ").append(losingTeam).append(String.format(" (%d points)", losingPoints));
        sb.append("\n>> Score Margin: ").append(winningPoints - losingPoints).append(" points");
        sb.append("\n>> -------------------------------------------------------");
        sb.append("\n>> Most Valuable Player (MVP): ").append(mvp);
        sb.append("\n>> Venue: ").append(stadium);
        sb.append("\n>> Location: ").append(city).append(", ").append(state);
        sb.append("\n>> =======================================================");
        
        return sb.toString();
    }
}