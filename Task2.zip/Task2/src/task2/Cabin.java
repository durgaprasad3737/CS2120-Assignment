package task2;

import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;
import java.util.stream.Collectors;

/**
 * Abstract class representing a Cabin on a Ship.
 * Provides core functionality for holding and managing passengers.
 * This is an abstract class that demonstrates inheritance and polymorphism.
 * Concrete implementations: Suite and StandardCabin.
 */
public abstract class Cabin {
    private final String number;
    private final int maxCapacity;
    // List of passengers currently residing in this cabin
    private final List<Passenger> passengers; 

    /**
     * Constructor for Cabin base class.
     * 
     * @param number The cabin number/identifier
     * @param maxCapacity Maximum number of passengers the cabin can accommodate
     */
    public Cabin(String number, int maxCapacity) {
        this.number = number;
        this.maxCapacity = maxCapacity;
        this.passengers = new ArrayList<>();
    }

    // --- Getter Methods ---
    public String getNumber() {
        return number;
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }
    
    /**
     * Abstract method to get the type description.
     * Demonstrates polymorphism: each subclass provides its own implementation.
     * 
     * @return Description of cabin type
     */
    public abstract String getTypeDescription();

    public List<Passenger> getPassengers() {
        return passengers;
    }

    /**
     * Gets current number of passengers in cabin.
     * 
     * @return Current occupancy count
     */
    public int getCurrentOccupancy() {
        return passengers.size();
    }

    /**
     * Calculates available space in cabin.
     * 
     * @return Available passenger slots
     */
    public int getAvailableSpace() {
        return maxCapacity - passengers.size();
    }

    /**
     * Checks if cabin is vacant (no passengers).
     * 
     * @return True if cabin is empty, false otherwise
     */
    public boolean isVacant() {
        return passengers.isEmpty();
    }
    
    /**
     * Checks if cabin can accommodate more passengers.
     * 
     * @return True if there is available space, false otherwise
     */
    public boolean canAccommodate() {
        return getCurrentOccupancy() < maxCapacity;
    }

    /**
     * Adds a passenger to the cabin and sets the cabin reference on the passenger.
     * Demonstrates bidirectional relationship management.
     * 
     * @param passenger The passenger to add
     * @throws IllegalStateException if cabin is full
     */
    public void addPassenger(Passenger passenger) {
        if (canAccommodate()) {
            this.passengers.add(passenger);
            passenger.setResidesIn(this); // Set bidirectional relationship
        } else {
            throw new IllegalStateException("Cabin " + number + " is full. Cannot accommodate more passengers.");
        }
    }

    /**
     * Removes a passenger from the cabin.
     * Note: Does not unset the cabin on the passenger as this is usually
     * called during a move/transfer operation.
     * 
     * @param passenger The passenger to remove
     */
    public void removePassenger(Passenger passenger) {
        this.passengers.remove(passenger);
        // Note: Do not unset the cabin on the passenger here
        // This is typically done when adding to new cabin
    }
    
    /**
     * Returns a list of passengers sharing the cabin with the specified passenger.
     * Sorted alphabetically by name as required by Use Case 3.
     * 
     * @param excludedPassenger The passenger to exclude from the list
     * @return List of cabin mates sorted alphabetically
     */
    public List<Passenger> getCabinMates(Passenger excludedPassenger) {
        return passengers.stream()
                .filter(p -> p != excludedPassenger)
                .sorted(Comparator.comparing(Passenger::getName))
                .collect(Collectors.toList());
    }
}